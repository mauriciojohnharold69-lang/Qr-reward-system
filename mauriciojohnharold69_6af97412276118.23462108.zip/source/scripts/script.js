"use strict";

/* =====================================
   ECOPOINTS CONFIGURATION
===================================== */

const WASTE_TYPES = [
  { id: "plastic", name: "Plastic", points: 10 },
  { id: "paper", name: "Paper", points: 10 },
  { id: "metal", name: "Metal", points: 15 },
  { id: "glass", name: "Glass", points: 15 }
];

const REWARDS = [
  { id: "rice1", name: "1 kg Rice", cost: 20 },
  { id: "rice3", name: "3 kg Rice", cost: 50 },
  { id: "grocery1", name: "Basic Groceries", cost: 40 },
  { id: "grocery2", name: "Family Grocery Pack", cost: 60 }
];

// Demo only: these PINs are NOT secure authentication.
const ADMIN_ACCOUNTS = [
  { name: "Admin 1", pin: "1111" },
  { name: "Admin 2", pin: "2222" },
];

const $ = id => document.getElementById(id);

const on = (id, type, handler) => {
  const element = $(id);

  if (!element) {
    console.warn("Missing element: #" + id);
    return;
  }

  element.addEventListener(type, handler);
};

const setText = (id, value) => {
  const element = $(id);
  if (element) element.textContent = value;
};

const setHTML = (id, value) => {
  const element = $(id);
  if (element) element.innerHTML = value;
};

const escapeHTML = value =>
  String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);

const formatDate = date =>
  new Date(date).toLocaleString();

const formatPoints = points =>
  Number(Number(points).toFixed(2)).toString();

/* =====================================
   CLASS 1: DATABASE
===================================== */

class EcoDatabase {
  constructor() {
    this.name = "EcoPointsDatabase";
    this.version = 2;
    this.db = null;
  }

  open() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error("IndexedDB is not supported."));
        return;
      }

      const request = indexedDB.open(
        this.name,
        this.version
      );

      request.onupgradeneeded = event => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains("submissions")) {
          db.createObjectStore("submissions", {
            keyPath: "id"
          });
        }

        if (!db.objectStoreNames.contains("redemptions")) {
          db.createObjectStore("redemptions", {
            keyPath: "id"
          });
        }

        if (!db.objectStoreNames.contains("members")) {
          db.createObjectStore("members", {
            keyPath: "id"
          });
        }
      };

      request.onsuccess = () => {
        this.db = request.result;

        this.db.onversionchange = () => {
          this.db.close();
          this.db = null;
        };

        resolve(this.db);
      };

      request.onblocked = () =>
        reject(new Error(
          "Database is blocked by another tab. Close other tabs and reload."
        ));

      request.onerror = () =>
        reject(request.error);
    });
  }

  store(name, mode = "readonly") {
    if (!this.db) {
      throw new Error("Database is not open.");
    }

    return this.db.transaction(name, mode)
                  .objectStore(name);
  }

  add(name, data) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(name, "readwrite");
      tx.objectStore(name).add(data);
      tx.oncomplete = () => resolve(data);
      tx.onabort = () => reject(tx.error);
      tx.onerror = () => reject(tx.error);
    });
  }

  put(name, data) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(name, "readwrite");
      tx.objectStore(name).put(data);
      tx.oncomplete = () => resolve(data);
      tx.onabort = () => reject(tx.error);
      tx.onerror = () => reject(tx.error);
    });
  }

  get(name, id) {
    return new Promise((resolve, reject) => {
      const request = this.store(name).get(id);

      request.onsuccess = () =>
        resolve(request.result);

      request.onerror = () =>
        reject(request.error);
    });
  }

  getAll(name) {
    return new Promise((resolve, reject) => {
      const request = this.store(name).getAll();

      request.onsuccess = () =>
        resolve(request.result || []);

      request.onerror = () =>
        reject(request.error);
    });
  }

  // Atomic redemption prevents overspending
  // when multiple requests happen together.
  redeem(reward) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(
        ["submissions", "redemptions"],
        "readwrite"
      );

      const submissions = tx.objectStore("submissions");
      const redemptions = tx.objectStore("redemptions");

      let errorMessage = "Redemption failed.";
      let record;

      const submissionRequest = submissions.getAll();

      submissionRequest.onsuccess = () => {
        const earned = submissionRequest.result
          .filter(s => s.status === "approved")
          .reduce((sum, s) => sum + s.points, 0);

        const spentRequest = redemptions.getAll();

        spentRequest.onsuccess = () => {
          const spent = spentRequest.result.reduce(
            (sum, r) => sum + r.cost, 0
          );

          if (earned - spent < reward.cost) {
            errorMessage = "Not enough EcoPoints.";
            tx.abort();
            return;
          }

          record = {
            id: crypto.randomUUID(),
            rewardId: reward.id,
            name: reward.name,
            cost: reward.cost,
            status: "claimed",
            date: new Date().toISOString()
          };

          redemptions.add(record);
        };
      };

      tx.oncomplete = () => resolve(record);
      tx.onabort = () => reject(
        new Error(errorMessage)
      );
    });
  }

  // Admin changes status only if still pending.
  updateStatus(id, status, reviewer = "") {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(
        "submissions", "readwrite"
      );

      const store = tx.objectStore("submissions");
      let updated = false;

      const request = store.get(id);

      request.onsuccess = () => {
        const submission = request.result;

        if (!submission ||
            submission.status !== "pending") {
          tx.abort();
          return;
        }

        submission.status = status;
        submission.reviewedBy = reviewer;
        submission.reviewedAt =
          new Date().toISOString();

        store.put(submission);
        updated = true;
      };

      tx.oncomplete = () => resolve(updated);
      tx.onabort = () => resolve(false);
      tx.onerror = () => reject(tx.error);
    });
  }
}

/* =====================================
   CLASS 2: WASTE SUBMISSION
===================================== */

class WasteSubmission {
  constructor(type, weight, photo) {
    const waste = WASTE_TYPES.find(
      item => item.id === type
    );

    if (!waste) {
      throw new Error("Invalid waste category.");
    }

    if (!Number.isFinite(weight) ||
        weight <= 0 || weight > 1000) {
      throw new Error("Invalid waste weight.");
    }

    this.id = crypto.randomUUID();
    this.type = waste.id;
    this.weight = weight;
    this.points = Number(
      (weight * waste.points).toFixed(2)
    );
    this.photo = photo;
    this.status = "pending";
    this.date = new Date().toISOString();
  }

  getQRData() {
    return JSON.stringify({
      app: "EcoPoints",
      submissionId: this.id
    });
  }
}

/* =====================================
   CLASS 3: REWARDS SYSTEM
===================================== */

class RewardSystem {
  constructor(database) {
    this.database = database;
  }

  async getBalance() {
    const submissions =
      await this.database.getAll("submissions");

    const redemptions =
      await this.database.getAll("redemptions");

    const earned = submissions
      .filter(item => item.status === "approved")
      .reduce((total, item) =>
        total + item.points, 0);

    const spent = redemptions
      .reduce((total, item) =>
        total + item.cost, 0);

    return Math.max(0, Number(
      (earned - spent).toFixed(2)
    ));
  }

  async redeem(rewardId) {
    const reward = REWARDS.find(
      item => item.id === rewardId
    );

    if (!reward) {
      throw new Error("Reward not found.");
    }

    if (!confirm(
      `Redeem ${reward.name} for ${reward.cost} points?`
    )) {
      return false;
    }

    await this.database.redeem(reward);
    alert("Reward redeemed successfully!");
    return true;
  }
}

/* =====================================
   CLASS 4: QR SCANNER
===================================== */

class EcoQRScanner {
  constructor(database) {
    this.database = database;
    this.scanner = null;
    this.running = false;
    this.busy = false;
  }

  async handleResult(text) {
    if (this.busy) return;
    this.busy = true;

    try {
      const data = JSON.parse(text);

      if (data.app !== "EcoPoints" ||
          typeof data.submissionId !== "string") {
        throw new Error("Not an EcoPoints QR code.");
      }

      const record = await this.database.get(
        "submissions",
        data.submissionId
      );

      if (!record) {
        throw new Error(
          "Submission not found in this database."
        );
      }

      setText("scanResult",
        `Verified submission: ${record.type}, ` +
        `${record.weight} kg, ` +
        `${record.points} points. ` +
        `Status: ${record.status}.`);

      await this.stop();
    } catch (error) {
      setText("scanResult",
        "QR scan: " + error.message);
    } finally {
      this.busy = false;
    }
  }

  async start() {
    if (this.running) return;

    if (typeof Html5Qrcode === "undefined") {
      alert("QR library not loaded. Check internet.");
      return;
    }

    if (!window.isSecureContext) {
      alert("Camera requires HTTPS or localhost.");
      return;
    }

    try {
      this.scanner = new Html5Qrcode("qr-reader");

      await this.scanner.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: { width: 230, height: 230 }
        },
        text => this.handleResult(text),
        () => {}
      );

      this.running = true;
      setText("scanResult",
        "Camera started. Scan your QR code.");
    } catch (error) {
      setText("scanResult",
        "Camera error: " + error.message);

      this.scanner = null;
      this.running = false;
    }
  }

  async stop() {
    if (this.scanner && this.running) {
      try {
        await this.scanner.stop();
      } catch (error) {
        console.warn(error);
      }
    }

    this.running = false;

    if (this.scanner) {
      try {
        this.scanner.clear();
      } catch (error) {
        console.warn(error);
      }
    }

    this.scanner = null;
  }

  async scanFile(file) {
    if (!file) return;

    await this.stop();

    if (typeof Html5Qrcode === "undefined") {
      alert("QR scanner library is unavailable.");
      return;
    }

    const reader = new Html5Qrcode("qr-reader");

    try {
      const result = await reader.scanFile(file, true);
      await this.handleResult(result);
    } catch (error) {
      setText("scanResult",
        "Unable to read QR image: " + error.message);
    } finally {
      try {
        reader.clear();
      } catch (error) {
        console.warn(error);
      }
    }
  }
}

/* =====================================
   CLASS 5: MAIN APPLICATION
===================================== */

class EcoPointsApp {
  constructor() {
    this.database = new EcoDatabase();
    this.rewards = new RewardSystem(this.database);
    this.scanner = new EcoQRScanner(this.database);
    this.adminUnlocked = false;
    this.currentAdmin = null;
    this.photoURL = null;
  }

  async init() {
    await this.database.open();

    this.bindEvents();
    await this.refresh();

    console.log("EcoPoints database ready.");
  }

  memberKey(name) {
    return String(name || "")
      .trim()
      .replace(/\s+/g, " ")
      .toLowerCase();
  }

  async checkMember() {
    const input = $("memberName");
    const key = this.memberKey(input ? input.value : "");

    if (!key) {
      setText("memberStatus", "");
      return null;
    }

    const member = await this.database.get("members", key);

    setText("memberStatus", member
      ? member.name + " is already registered."
      : "Not registered yet.");

    return member || null;
  }

  async registerMember(event) {
    event.preventDefault();

    const input = $("memberName");
    const name = input
      ? input.value.trim().replace(/\s+/g, " ")
      : "";
    const key = this.memberKey(name);

    if (!key) {
      setText("memberStatus", "Please enter a member name.");
      return;
    }

    try {
      const existing = await this.database.get("members", key);

      if (existing) {
        setText("memberStatus",
          existing.name + " is already registered.");
        return;
      }

      await this.database.add("members", {
        id: key,
        name: name,
        date: new Date().toISOString()
      });

      setText("memberStatus",
        name + " has been registered successfully.");
    } catch (error) {
      setText("memberStatus",
        "Registration error: " + error.message);
    }
  }

  bindEvents() {
    on("memberName", "input", () => {
      this.checkMember().catch(error => console.warn(error));
    });

    on("memberForm", "submit", event => this.registerMember(event));

    on("wasteType", "change", () => this.calculatePoints());

    on("weight", "input", () => this.calculatePoints());

    on("wastePhoto", "change", event => {
      const file = event.target.files[0];
      const preview = $("photoPreview");

      if (this.photoURL) {
        URL.revokeObjectURL(this.photoURL);
        this.photoURL = null;
      }

      if (file) {
        this.photoURL = URL.createObjectURL(file);

        if (preview) {
          preview.src = this.photoURL;
          preview.hidden = false;
        }
      } else if (preview) {
        preview.hidden = true;
      }
    });

    on("wasteForm", "submit", event => this.submitWaste(event));

    on("startScanner", "click", () => this.scanner.start());

    on("stopScanner", "click", async () => {
      await this.scanner.stop();
      setText("scanResult", "Scanner stopped.");
    });

    on("qrUpload", "change", async event => {
      await this.scanner.scanFile(
        event.target.files[0]
      );
      event.target.value = "";
    });

    document.querySelectorAll("[data-reward]")
      .forEach(button => {
        button.addEventListener("click", async () => {
          try {
            const redeemed = await this.rewards.redeem(
              button.dataset.reward
            );

            if (redeemed) await this.refresh();
          } catch (error) {
            alert(error.message);
          }
        });
      });

    on("adminLogin", "click", () => {
      const pinInput = $("adminPin");
      const pin = pinInput ? pinInput.value.trim() : "";
      const admin = ADMIN_ACCOUNTS.find(
        account => account.pin === pin
      );

      if (admin) {
        this.adminUnlocked = true;
        this.currentAdmin = admin;

        const content = $("adminContent");
        if (content) content.hidden = false;

        if (pinInput) pinInput.value = "";
        this.renderAdmin();
      } else {
        alert("Incorrect admin PIN.");
      }
    });

    on("adminTable", "click", async event => {
      const button = event.target.closest(
        "button[data-action]"
      );

      if (!button || !this.adminUnlocked) return;

      const status = button.dataset.action;
      const id = button.dataset.id;

      if (!["approved", "rejected"].includes(status)) {
        return;
      }

      try {
        const updated = await this.database.updateStatus(
          id, status, this.currentAdmin.name
        );

        if (!updated) {
          alert("Submission is no longer pending.");
        }

        await this.refresh();
      } catch (error) {
        alert("Update error: " + error.message);
      }
    });

    on("exportData", "click", () => this.exportData());
  }

  calculatePoints() {
    const typeInput = $("wasteType");
    const weightInput = $("weight");

    const waste = WASTE_TYPES.find(
      item => typeInput && item.id === typeInput.value
    );

    const weight = Number(weightInput ? weightInput.value : 0);

    const points = waste &&
      Number.isFinite(weight) &&
      weight > 0
        ? weight * waste.points
        : 0;

    setText("potentialPoints",
      formatPoints(points) + " Points");
  }

  // Compress image before saving to IndexedDB.
  async compressImage(file) {
    if (!file.type.startsWith("image/")) {
      throw new Error("Please select an image.");
    }

    if (file.size > 15 * 1024 * 1024) {
      throw new Error("Image must be below 15 MB.");
    }

    const image = await createImageBitmap(file);

    try {
      const scale = Math.min(
        1, 1000 / Math.max(image.width, image.height)
      );

      const canvas = document.createElement("canvas");

      canvas.width = Math.max(
        1, Math.round(image.width * scale)
      );

      canvas.height = Math.max(
        1, Math.round(image.height * scale)
      );

      const context = canvas.getContext("2d");
      context.drawImage(
        image, 0, 0, canvas.width, canvas.height
      );

      return canvas.toDataURL("image/jpeg", 0.7);
    } finally {
      image.close();
    }
  }

  async submitWaste(event) {
    event.preventDefault();

    const button = event.submitter;
    if (button) button.disabled = true;

    try {
      const type = $("wasteType").value;
      const weight = Number($("weight").value);
      const file = $("wastePhoto").files[0];

      if (!file) {
        throw new Error("Upload a waste photo.");
      }

      const photo = await this.compressImage(file);

      const submission = new WasteSubmission(
        type, weight, photo
      );

      await this.database.add(
        "submissions", submission
      );

      this.generateQR(submission);

      $("wasteForm").reset();

      const preview = $("photoPreview");
      if (preview) preview.hidden = true;

      setText("potentialPoints", "0");

      alert(
        "Waste submitted! Waiting for admin approval."
      );

      await this.refresh();
    } catch (error) {
      alert("Submission error: " + error.message);
    } finally {
      if (button) button.disabled = false;
    }
  }

  generateQR(submission) {
    const generated = $("generatedQR");
    const container = $("qrcode");

    if (generated) generated.hidden = false;
    if (container) container.innerHTML = "";

    setText("submissionCode",
      "Submission ID: " + submission.id);

    if (!container) return;

    if (typeof QRCode === "undefined") {
      container.textContent =
        "QR library unavailable. Check internet.";
      return;
    }

    new QRCode(container, {
      text: submission.getQRData(),
      width: 200,
      height: 200,
      colorDark: "#08643d",
      colorLight: "#ffffff"
    });
  }

  async refresh() {
    const submissions =
      await this.database.getAll("submissions");

    const redemptions =
      await this.database.getAll("redemptions");

    const pending = submissions
      .filter(item => item.status === "pending")
      .reduce((sum, item) => sum + item.points, 0);

    const earned = submissions
      .filter(item => item.status === "approved")
      .reduce((sum, item) => sum + item.points, 0);

    const spent = redemptions
      .reduce((sum, item) => sum + item.cost, 0);

    const balance = Math.max(
      0, Number((earned - spent).toFixed(2))
    );

    setText("availablePoints", formatPoints(balance));
    setText("pendingPoints", formatPoints(pending));
    setText("totalWaste", submissions.length);
    setText("claimedRewards", redemptions.length);
    setText("rewardBalance", formatPoints(balance) + " Points");

    this.renderRecords(submissions);
    this.renderRedemptions(redemptions);

    if (this.adminUnlocked) {
      await this.renderAdmin(submissions);
    }
  }

  renderRecords(records) {
    if (!records.length) {
      setHTML("recordsTable",
        '<tr><td colspan="6">No records yet.</td></tr>');
      return;
    }

    setHTML("recordsTable", [...records]
      .sort((a, b) => b.date.localeCompare(a.date))
      .map(item => `
        <tr>
          <td>${escapeHTML(item.id.slice(0, 8))}</td>
          <td>${escapeHTML(formatDate(item.date))}</td>
          <td>${escapeHTML(item.type)}</td>
          <td>${escapeHTML(item.weight)} kg</td>
          <td>${formatPoints(item.points)}</td>
          <td>
            <span class="status ${escapeHTML(item.status)}">
              ${escapeHTML(item.status)}
            </span>
          </td>
        </tr>
      `).join(""));
  }

  renderRedemptions(records) {
    if (!records.length) {
      setHTML("redemptionTable",
        '<tr><td colspan="4">No rewards yet.</td></tr>');
      return;
    }

    setHTML("redemptionTable", [...records]
      .sort((a, b) => b.date.localeCompare(a.date))
      .map(item => `
        <tr>
          <td>${escapeHTML(formatDate(item.date))}</td>
          <td>${escapeHTML(item.name)}</td>
          <td>${escapeHTML(item.cost)}</td>
          <td>
            <span class="status approved">
              Claimed
            </span>
          </td>
        </tr>
      `).join(""));
  }

  async renderAdmin(records = null) {
    if (!this.adminUnlocked) return;

    const all = records ||
      await this.database.getAll("submissions");

    const pending = all.filter(
      item => item.status === "pending"
    );

    if (!pending.length) {
      setHTML("adminTable",
        '<tr><td colspan="5">No pending submissions.</td></tr>');
      return;
    }

    setHTML("adminTable", pending.map(item => `
      <tr>
        <td>${escapeHTML(item.id.slice(0, 8))}</td>
        <td>
          ${escapeHTML(item.type)}
          (${escapeHTML(item.weight)} kg)
        </td>
        <td>${formatPoints(item.points)}</td>
        <td>
          <img class="admin-photo"
               src="${escapeHTML(item.photo)}"
               alt="Submitted waste">
        </td>
        <td>
          <div class="action-buttons">
            <button data-id="${escapeHTML(item.id)}"
                    data-action="approved">
              Approve
            </button>
            <button class="reject"
                    data-id="${escapeHTML(item.id)}"
                    data-action="rejected">
              Reject
            </button>
          </div>
        </td>
      </tr>
    `).join(""));
  }

  async exportData() {
    try {
      const data = {
        exportedAt: new Date().toISOString(),
        members:
          await this.database.getAll("members"),
        submissions:
          await this.database.getAll("submissions"),
        redemptions:
          await this.database.getAll("redemptions")
      };

      const blob = new Blob(
        [JSON.stringify(data, null, 2)],
        { type: "application/json" }
      );

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = url;
      link.download = "ecopoints-database.json";
      link.click();

      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      alert("Export error: " + error.message);
    }
  }
}

/* =====================================
   START APPLICATION
===================================== */

const app = new EcoPointsApp();

document.addEventListener("DOMContentLoaded", () => {
  app.init().catch(error => {
    console.error(error);
    alert(
      "Unable to initialize EcoPoints database: " +
      error.message
    );
  });
});
